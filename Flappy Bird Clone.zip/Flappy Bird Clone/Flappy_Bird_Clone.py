import flet as ft
import asyncio 
import random 

async def main(page: ft.Page):

    # CREATION DE LA FENETRE DE JEU ⭐
    page.title = "Flappy Bird Clone"
    page.window_width = 400
    page.window_height = 600
    page.bgcolor = "#BDE0FE"
    padding = 0


    # ÉTAT DU JEU ⭐
    state = {"accueil":True ,"game_active": False, "game_over":False, "pipe_passed": False, "score": 0, "high_score": 0, "bird_mouvement": 0, "speed":5}


    # ELEMENTS VISUELS ⭐

    # ACCUEIL 1️⃣
    accueil_text = ft.Container(content=ft.Text("Appuyez sur Espace pour commencer", size=10, font_family="Booked"), width=200, top=520, left=100)
    accueil_logo = ft.Container(content=ft.Image(src="LOGO.png"), height=150, width=250, top=150, left=75)
    accueil_background=ft.Container(width=400, height=600, bgcolor="blue")

    # MENU THEME 2️⃣

    # INTRO 3️⃣
    score_text = ft.Text("0", size=40, color="white", weight="bold", top=40, left=185, visible=False)

    # JEU 4️⃣
    bird=ft.Container(height=30, width=30, top=300, left=50, content= ft.Image(src="flappy.png"), visible=False)
    pipe_top=ft.Container(height=600, width=60, left=450, top=-400, content=ft.Image(src="top_pipe.png"))
    pipe_bottom=ft.Container(height=600, width=60, left=450, top=350, content=ft.Image(src="bottom_pipe.png"))
    nuage1=ft.Container(height=60, width=400, top=0, left=-50, content=ft.Image(src="Nuage1.png", fit="fill"), visible=False)
    nuage2=ft.Container(height=60, width=400, top=0, left=350, content=ft.Image(src="Nuage2.png"), visible=False)
    pelouse1=ft.Container(height=60, width=400, top=540, left=-50, content=ft.Image(src="Pelouse1.png", fit="fill"), visible=False)
    pelouse2=ft.Container(height=60, width=400, top=540, left=350, content=ft.Image(src="Pelouse2.png", fit="fill"), visible=False)
    game_background=ft.Container(width=400, height=600, bgcolor="#bde0fe")

    # GAME OVER SCREEN 5️⃣
    game_over_screen = ft.Container(content=ft.Text("GAME\nOVER", size=50, font_family="vhs/vcr osd", color="white"), width=180, top=150, left=120, visible=True)
    high_score = ft.Text(f"Meilleur Score: {state['high_score']}", size=20, color="yellow", weight="bold",align=ft.Alignment.CENTER)
    background = ft.Container(width=400, height=600, bgcolor="black")


    # LOGIQUE DE COLLISION ⭐

    def Impact():
        if bird.top <= 0 or bird.top >= 570:
            return True
        if bird.left + 30 > pipe_top.left and bird.left < pipe_top.left + 60:
            if bird.top < pipe_top.top + 600 or bird.top + 30 > pipe_bottom.top:
                return True
        return False
    

    # INTERACTIONS AVEC LES TOUCHES ⭐

    def on_key_down(e: ft.KeyboardEvent):
        if e.key == " ":
            if state["accueil"]:
                state["game_active"] = True
                state["accueil"]=False
                state["game_over"]=False
                return
            
            if state["game_active"]:
                state["bird_mouvement"] = -7
                return
            
            else:
                # RÉINITIALISATION
                state["accueil"]=False
                state["game_active"] = True
                state["game_over"]=False
                state["pipe_passed"] = False
                state["score"] = 0
                state["bird_mouvement"] = 0 
                pipe_top.left = 450
                pipe_bottom.left = 450
                bird.top = 300
                score_text.value = "0"
            page.update()

        if e.key == "Backspace":
            if state["accueil"]:
                return
            if state["game_active"]:
                return
            else:
                state["accueil"]=True

    page.on_keyboard_event = on_key_down


    # LE STACK (SUPERPOSITION DES OBJETS) ⭐

    game_area = ft.Stack([accueil_background, accueil_logo, accueil_text,
                          game_background, bird, pipe_top, pipe_bottom, nuage1, nuage2, pelouse1, pelouse2, score_text,
                          background, game_over_screen, high_score],
                          width=400, height=600)
    
    page.add(game_area)


    # LE JEU ⭐⭐

    while True:
        if state["accueil"]:
            state["game_active"]=False
            state["game_over"]=False
            state["bird_mouvement"]=0

            accueil_background.visible=True
            accueil_logo.visible=True
            accueil_text.visible=True
            game_background.visible=False
            bird.visible=False
            pipe_top.visible=False
            pipe_bottom.visible=False
            nuage1.visible=False
            nuage2.visible=False
            pelouse1.visible=False
            pelouse2.visible=False
            score_text.visible=False
            background.visible=False
            game_over_screen.visible=False
            high_score.visible=False


        if state["game_active"]:
            state["accueil"]=False
            state["game_over"]=False

            state["bird_mouvement"] += 0.5
            bird.top += state["bird_mouvement"]
            pipe_top.left -= state["speed"]
            pipe_bottom.left -= state["speed"]
            nuage1.left -= state["speed"]
            nuage2.left -= state["speed"]
            pelouse1.left -= state["speed"]
            pelouse2.left -= state["speed"]
            
            accueil_background.visible=False
            accueil_logo.visible=False
            accueil_text.visible=False
            game_background.visible=True
            bird.visible=True
            pipe_top.visible=True
            pipe_bottom.visible=True
            nuage1.visible=True
            nuage2.visible=True
            pelouse1.visible=True
            pelouse2.visible=True
            score_text.visible=True
            background.visible=False
            game_over_screen.visible=False
            high_score.visible=False

            # GESTION DU SCORE
            if pipe_top.left + pipe_top.width < bird.left and not state["pipe_passed"]: 
                state["score"] += 1
                score_text.value = str(state['score'])
                state["pipe_passed"] = True

            # REINITIALISATION DES TUYAUX
            if pipe_top.left < -50: 
                pipe_top.left = 400
                pipe_bottom.left = 400
                h = random.randint(100, 350)
                gap = random.randint(90, 180)
                pipe_top.top = h - 600
                pipe_bottom.top = h + gap
                state["pipe_passed"]=False

            # REINITIALISATION DE LA PELOUSE ET DES NUAGES
            if nuage1.left <= -400:
                nuage1.left = nuage2.left + 400
            if nuage2.left <= -400:
                nuage2.left = nuage1.left + 400

            if pelouse1.left <= -400:
                pelouse1.left = pelouse2.left+400
            if pelouse2.left <= -400:
                pelouse2.left = pelouse1.left+400

            # VARIATION DE LA VITESSE
            if state["score"] < 10:
                state["speed"] = 5
            if state["score"] == 10:
                state["speed"] = 6
            if state["score"] == 15:
                state["speed"] = 7
            if state["score"] == 20:
                state["speed"] = 8
            if state["score"] == 30:
                state["speed"] = 9
            if state["score"] == 35:
                state["speed"] = 3
            if state["score"] == 36:
                state["speed"] = 9
            
        
            # EN CAS D'IMPACT
            if Impact():
                state["accueil"]=False
                state["game_active"] = False
                state["game_over"]=True


                if state["score"] > state["high_score"]:
                    state["high_score"] = state["score"]
                high_score.value = f"Meilleur Score: {state['high_score']}"
                
                accueil_background.visible=False
                accueil_logo.visible=False
                accueil_text.visible=False
                game_background.visible=False
                bird.visible=False
                pipe_top.visible=False
                pipe_bottom.visible=False
                nuage1.visible=False
                nuage2.visible=False
                pelouse1.visible=False
                pelouse2.visible=False
                score_text.visible=False
                background.visible=True
                game_over_screen.visible=True
                high_score.visible=True

        page.update()
        await asyncio.sleep(0.016)
        

ft.run(main)